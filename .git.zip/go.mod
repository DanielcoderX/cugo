module github.com/cugo/cugo

go 1.26.0

require golang.org/x/sys v0.48.0 // indirect
